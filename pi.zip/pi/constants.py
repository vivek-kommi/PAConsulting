YOLOV3_LABELS_PATH = 'C:/Users/prana/OneDrive/Documents/Python Scripts/pi/yolov3/coco.names'
YOLOV3_CFG_PATH = 'C:/Users/prana/OneDrive/Documents/Python Scripts/pi/yolov3/yolov3.cfg'
YOLOV3_WEIGHTS_PATH = 'C:/Users/prana/OneDrive/Documents/Python Scripts/pi/yolov3/yolov3.weights'
VIDEO_PATH = 'C:/Users/prana/OneDrive/Documents/Python Scripts/pi/videos/video.mp4'
OUTPUT_PATH = 'C:/Users/prana/OneDrive/Documents/Python Scripts/pi/output/output.avi'
SAFE_DISTANCE = 60
