# Translator

Language - Python 3

## Required Packages ##
- OpenCV
- pytesseract
- PyDictionary
- googletrans
- Tkinter
- numpy